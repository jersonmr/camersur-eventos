$("#calendar").calendario({
    displayWeekAbbr: true,
    displayMonthAbbr: true
});